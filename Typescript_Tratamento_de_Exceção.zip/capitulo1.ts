export class Capitulo1 {
  mensagem_de_excecao: string = 'Classe: capitulo 1'

  encontrar_direcao(direction: number): string {
    try {
      if (direction < 0 || direction > 360) throw new Error('Direção inválida')
      if (direction >= 338 || direction <= 22) return 'N'
      if (direction >= 23 && direction <= 67) return 'NE'
      if (direction >= 68 && direction <= 112) return 'E'
      if (direction >= 113 && direction <= 157) return 'SE'
      if (direction >= 158 && direction <= 202) return 'S'
      if (direction >= 203 && direction <= 247) return 'SW'
      if (direction >= 248 && direction <= 292) return 'W'
      if (direction >= 293 && direction <= 337) return 'NW'
      return '' // Essa linha nunca vai ser executada
    }
    catch (error) {
      console.error(this.mensagem_de_excecao, ' função: encontrar_direcao: ', error)
      throw new Error('Direção inválida')
    }
  }

  exercicio0() {
    try {
      const direcao: string = this.encontrar_direcao(-1)
      if (direcao.length === 0) throw new Error('Direção não encontrada')
      console.log(direcao)
    }
    catch (error) {
      console.error(this.mensagem_de_excecao, ' função: exercicio 0: ', error)
      throw new Error(`Erro ao executar função: exercício 0, classe: ${this.mensagem_de_excecao}`)
    }
  }
}