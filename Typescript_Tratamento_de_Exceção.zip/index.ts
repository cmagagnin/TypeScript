import { Capitulo1 } from './capitulo1';

function main(): void {
  try {
    const capitulo1: Capitulo1 = new Capitulo1()
    capitulo1.exercicio0()
  }
  catch (error) { // error é qualquer coisa que pode ser tratada como uma exceção
    console.error('Erro global detectado: ', error)
  }
}

main();