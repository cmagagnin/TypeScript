const divisao = (a: number, b: number): number => { return a / b; }
function soma(a: number, b: number): number { return a + b; }
function subtracao(a: number, b: number): number { return a - b; }
function multiplicacao(a: number, b: number): number { return a * b }

enum Operacao {
  soma = '+', subtracao = '-',
  multiplicacao = '*', divisao = '/'
};

function calculadora(a: number, b: number, operacao: Operacao): number {
  if (operacao === Operacao.soma) return soma(a, b);
  if (operacao === Operacao.divisao) return divisao(a, b);
  if (operacao === Operacao.multiplicacao) return multiplicacao(a, b);
  if (operacao === Operacao.subtracao) return subtracao(a, b);
  return 0;
}

function main() {
  let numero: number = 0
  let decimal = 0.0 // float, double e decimal
  let texto: string = ''
  let booleano: boolean = true // true ou false
  let array: number[] = [1, 2, 3]
  let objeto: { nome: string, idade: number } = { nome: '', idade: 24 } // struct
  let nulo: null = null
  let indefinido: undefined = undefined

  const valor = 0
  // valor = 1 // erro
  const lista: string[] = []
  lista.push('1')
  // lista = 1 // erro
  // lista = [] // erro

  const structPessoa: { nome: string, idade: number } = { nome: '', idade: 24 }
  structPessoa.nome = 'João'
  structPessoa.idade = 24

  console.log('print');
  console.warn('Aviso');
  console.error('Erro');
  console.info('Informação');
  console.debug('Debug');

  console.clear();

  const soma: number = calculadora(1, 1, Operacao.soma);
  console.debug('soma: ', soma);

  const divisao: number = calculadora(1, 1, Operacao.divisao);
  console.debug('divisao: ', divisao);

  const multiplicacao: number = calculadora(1, 1, Operacao.multiplicacao);
  console.debug('multiplicação: ', multiplicacao);

  const subtracao: number = calculadora(1, 1, Operacao.subtracao);
  console.debug('subtração: ', subtracao)
}
main();